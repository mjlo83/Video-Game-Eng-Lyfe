from game import Game

#starts game
if __name__ == '__main__':
    game = Game()
    game.run()
