#Import statements
import pygame,time
from spriteSheet import Spritesheet
from Tile import *
from Player import Player
from Camera import Camera
from Intro import IntroDialogue
from winning_screen import WinningScreen
from losing_screen import LosingScreen

def run_game(game):
    #load up basic window
    pygame.init()
    running = True
    

    clock = pygame.time.Clock()
    screen = pygame.display.set_mode((1000,1000))

    #Load instances of spritesheet (to help load map), Tilemap, Player, and Camera
    mySpriteSheet = Spritesheet("sp1.png")
    map = TileMap('EngLyffe.csv',mySpriteSheet)
    guy = Player("Guy.png",map,game.character)
    camera = Camera(guy)
    narrator = IntroDialogue(screen)

    guy.setCurrentTile()

    #Load up winning screen
    ws = WinningScreen(screen)
    #load up losing screen
    ls = LosingScreen(screen)


    #Health bar assets
    healthbar = pygame.image.load("playerHealthbar.png")
    healthBar_img = pygame.transform.scale(healthbar,(2*healthbar.get_rect().width,2*healthbar.get_rect().height))
    healthBar_rect = healthBar_img.get_rect()
    healthBar_rect.x= screen.get_rect().width-healthBar_rect.width
    healthBar_rect.y=0

    health_x =healthBar_rect.x+96
    health_y=healthBar_rect.y+34

    def win_check():
        if guy.currentHealth<=0:
            ls.start()
            return False
        if guy.winCounter==4:
            ws.start()
            return False
        return True

    
    #renders the map screen
    def render():
        #Calculates the health bar depending on remaining health; shrinks as health decreases
        health_width = int((guy.currentHealth/guy.stats[0])*96)
        #update player position
        guy.update()
        #update camera position
        camera.scroll()
        #clear screen
        screen.fill((0,0,0))
        #draw map,player, and health
        map.draw_map(screen,(0 - camera.offset.x, 0 - camera.offset.y))
        guy.draw(screen,(guy.rect.x - camera.offset.x, guy.rect.y - camera.offset.y))
        screen.blit(healthBar_img,healthBar_rect)
        if health_width>0:
            pygame.draw.rect(screen,(0,255,0),(health_x,health_y,health_width,6))
        
        #reset screen
        pygame.display.flip()


    narrator.start()

    running = True
    #game loop for map
    while running:
        #event loop
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running=False
            #Key pressed
            #used to find position on map (developer use)
            if event.type == pygame.MOUSEBUTTONDOWN:
                print(pygame.mouse.get_pos())
            #player movement; if a key is pressed and controls are not disabled (currently between nodes)
            if event.type == pygame.KEYDOWN and not guy.disableInput:
                #checks key and if current tile has a potential destination in direction pressed
                if event.key == pygame.K_w and guy.currentTile.WASD['W']!=None:
                    #sets moving to be W,S,A, or D (used in update())
                    guy.moving,guy.FACING_BACKWARD="W",False
                elif event.key == pygame.K_s and guy.currentTile.WASD['S']!=None:
                    guy.moving,guy.FACING_BACKWARD="S",True
                elif event.key == pygame.K_a and guy.currentTile.WASD['A']!=None:
                    guy.moving,guy.FACING_LEFT="A",True
                elif event.key==pygame.K_d and guy.currentTile.WASD['D']!=None:
                    guy.moving,guy.FACING_LEFT="D",False
        #call render
        render()
        #checks if player has won or lost
        running = win_check()
        #sleep
        time.sleep(0.05)

    #quit pygame
    pygame.quit()
